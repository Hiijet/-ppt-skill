# 第三方项目 依赖与许可说明

核验记录日期：2026年11月10日。本文件用于说明已识别的关系，不是覆盖所有未来部署、依赖或素材的完整法律审计。公开分支可能变化，安装、修改、分发或提供服务前须核对实际使用版本和随附文件。

## 本仓库提供与未提供的内容

仓库提供工作流文字、独立状态管理脚本、SVG预览辅助脚本、测试和示例参数。未打包PPT Master、Playwright、MinerU、Python、Node.js的实现代码、安装包、浏览器或模型。为保留来源信息，本目录另附部分工具的许可和NOTICE文本。

工作流形成于使用PPT Master和宿主平台工具进行逐页制作的实践中。这里不作“完全从零且与任何第三方无关”的声明；也不把调用关系直接判断为法律上的派生关系。若后续发现实际包含第三方代码或实质文档片段，应进一步确定来源、许可范围和需保留的声明。

## PPT Master

- 上游：https://github.com/hugohe3/ppt-master
- 已核对来源：https://github.com/hugohe3/ppt-master/blob/main/LICENSE
- 上游声明：MIT；Copyright (c) 2025-2026 Hugo He。
- 关系：可选外部制作与导出后端；接入文档包含其工具和命令名称。实践记录的本地版本为6.7.0，逐页流程含本地扩展，未核定该本地安装与某个上游提交完全一致。
- 保留许可：[ppt-master-MIT.txt](third_party_licenses/ppt-master-MIT.txt)。此副本来自本地安装，其许可类型及署名与本次浏览的上游页面相符；不是附带完整PPT Master实现的声明。
- 后续复制或分发上游软件或其实质部分时，应保留适用的版权与许可声明，并检查具体材料、依赖和资产是否另有条款。不得改写上游署名为本项目作者。

## Playwright

- 上游：https://github.com/microsoft/playwright
- 已核对来源：https://github.com/microsoft/playwright/blob/main/LICENSE
- 关系：render_preview.mjs在运行时导入Playwright；独立状态器本身不依赖它。
- 本地核对版本：1.62.1；其包元数据标注Apache-2.0，并依赖playwright-core 1.62.1。
- 保留文本：[许可证](third_party_licenses/playwright-APACHE2.txt) 与 [NOTICE](third_party_licenses/playwright-NOTICE.txt)，来自本次查看的本地1.62.1包。库实现、playwright-core、其他传递依赖和浏览器均未分发。
- 后续打包Playwright或其依赖时，须按实际版本复核LICENSE、NOTICE、ThirdPartyNotices及传递依赖义务，不能只复制本仓库这两份文本就视为完成所有许可工作。浏览器和系统字体另有其许可。

## MinerU

- 上游：https://github.com/opendatalab/MinerU
- 已核对来源：https://github.com/opendatalab/MinerU/blob/master/LICENSE.md
- 关系：文档推荐的可选解析工具，可由用户环境的服务或连接器提供；本仓库不导入、安装或分发其代码和模型。
- 本次浏览的公开许可表述为Apache-2.0加附加条款，包含特定规模下的商业许可要求和基于MinerU提供在线服务的显著标识义务。应阅读完整原文，不能简化成无条件Apache-2.0或所有商业用途都免许可。
- 未核实用户本地MinerU服务的具体版本、连接器来源、模型权重及服务合同。不同版本或服务不应自动沿用本次浏览分支的结论。使用或部署前须记录所用版本及许可；模型权重和外部API服务可能具有独立条款。
- 本清单感谢其提供的解析能力，但不替任何安装版本声明已获商业授权，也不判断其是否符合某组织的开源定义。

## 运行时 备选工具与平台

- Python：https://www.python.org/psf/license/ 。Node.js：https://github.com/nodejs/node/blob/main/LICENSE 。二者为外部运行时；本包未分发，安装版本及其随附组件须由部署者核对。
- 文档提到python-pptx、PptxGenJS、LibreOffice等作为可能的替代方式，不代表当前脚本全部导入或已验证这些项目。选择后须另记版本、许可与依赖。
- PowerPoint、Edge及AI宿主平台可能适用专有许可、账户与服务条款；不能以本项目MIT许可证替代。平台回传API示例不代表附带平台源码或可绕过访问限制。

## 来源核验的边界

上述在线链接为可变分支，未作为锁定依赖或不可变提交证明。manifest记录的是当前包的文件哈希，不是完整SBOM或法律认证。正式集成或再分发时，建议固定依赖版本与提交、保存其许可证据并重新核验。

本说明不表示与Hugo He、Microsoft、OpenDataLab、OpenAI或其他提供方存在合作、隶属、认证或背书；项目名称仅用于客观说明来源和兼容关系，不授予商标、Logo或素材的使用权。
