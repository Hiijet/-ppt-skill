# 独立状态器：用法与关卡

只在项目没有 PPT Master `page_workflow.json` 时使用；脚本会拒绝静默接管该项目。状态在 `PROJECT/product/page-by-page/portable_workflow.json`。

## 命令

```text
python scripts/workflow.py init --main MAIN --name NAME --canvas 1280 720 --academic undecided
python scripts/workflow.py --project PROJECT settings --academic disabled --evidence "用户明确说不使用"
python scripts/workflow.py --project PROJECT template --path TEMPLATE --study STUDY_JSON --evidence "确认模板观察与继承项的实际回复"
python scripts/workflow.py --project PROJECT asset --path FILE --kind original_image --label "作者/原文图号/类型"
python scripts/workflow.py --project PROJECT add --brief PAGE_BRIEF_JSON
python scripts/workflow.py --project PROJECT confirm --page p0001 --evidence "是，按此方案制作预览"
# 只制作本页；运行后端真正的QA，保存qa.json：
python scripts/workflow.py --project PROJECT generated --page p0001 --artifact PAGE_SOURCE --qa QA_JSON
# 真正渲染、展示截图后：
python scripts/workflow.py --project PROJECT preview --page p0001 --artifact SCREENSHOT --shown-as "实际展示的图片路径或URL"
python scripts/workflow.py --project PROJECT approve --page p0001 --evidence "是，本页定稿"
# 修改前：
python scripts/workflow.py --project PROJECT reopen --page p0001 --brief NEW_BRIEF --evidence "实际修改要求"
# 重新确认、制作、预览、定稿。查询：
python scripts/workflow.py --project PROJECT status
python scripts/workflow.py --project PROJECT audit
# 用户明确要求最终导出后才申请就绪收据（不执行导出）：
python scripts/workflow.py --project PROJECT export-ready --evidence "用户实际汇总请求"
```

`add` 返回稳定ID，使用实际返回值，不盲目假定 p0001。一个页面未定稿时不能添加下一页。`reopen` 归档旧brief、源、QA和预览；不改原始模板或素材。工具仅做单写入者串行工作流，不支持多个代理同时更改状态。

## Brief

必填：`kind`、`title`、非空 `content`、`language`、`layout`、`alignment`、`spacing`、`template_application`、`materials`、`text_roles`。`materials` 为登记资产ID。每种文字角色有非空 `font`、正数 `size_pt`、`#RRGGBB` 颜色。示例在 `assets/page-brief.example.json`，必须先替换成实际确认值。

模板学习记录至少包含：来源路径及sha256、实际画布、所观察页号、测得的字体字号/继承链/颜色/位置、尚未检查页型，以及拟继承与覆盖项。脚本只校验它是JSON；观察准确性由实际检查负责。

## QA适配文件

后端检查器产生真实结果后，由适配器保存以下摘要；同时保留原始报告。不得为了通过关卡编造 `passed` 或把未运行的检查写为通过。

```json
{
  "passed": true,
  "artifact_sha256": "实际页面源文件的sha256",
  "checks": ["后端SVG/页面结构检查", "字体与字号角色核对", "数值与来源逐项核对"]
}
```

独立状态器检验状态、素材/模板/brief/源/QA/截图是否过期，但不声称解析任意后端的版面、不证明截图一定已向用户展示、不验证引号中的文字确由用户发出。操作者必须如实记录用户回复与展示行为；证据字段不是密码学身份认证。

状态链：`brief_draft → brief_confirmed → generated → previewed → approved`。只有 `reopen` 可以返回草稿；输入哈希变化会阻止后续批准及最终审计。收到新请求先判断它属于参数批准、定稿还是修改，不混淆两种“是”。

## 可视化事件适配

完整协议见 [visual-review-protocol.md](visual-review-protocol.md)。真实用户按钮事件可转成上述命令的evidence，无需聊天二次确认。适配器先验证事件页ID、版本、哈希和状态，去重后串行调用状态器；命令成功才回显“已定稿”，随后自动展示下一页参数单。脚本本身不提供Web回调、事件去重或身份认证，不得把这些适配器责任宣称为已有功能。继续复用当前唯一状态文件，不引入另一套页面批准状态。
