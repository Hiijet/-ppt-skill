# 工具与命令：能力优先，不绑定模型

## 本次实际使用的工具及其职责

| 能力 | 本次工具 | 其他模型可采用的等价方式 |
|---|---|---|
| 阅读技能/文件、调用程序 | `functions.exec` → `exec_command`；PowerShell、Python | shell/终端/受控文件工具；按权限执行，不拼接破坏性跨shell命令 |
| 标准确认点 | `request_user_input_async`，选项“是／否”，并允许自由输入 | 其他表单工具；没有则普通聊天提问并停止 |
| 环境发现 | `load_workspace_dependencies` 查实际 Python/Node/库路径 | `python --version`、环境配置、包管理器只读查询；不猜硬编码路径 |
| 模板原生属性 | Python `zipfile` + `xml.etree.ElementTree`；PPT Master只读导入器 | OOXML解析、Office对象模型；仍需解析继承链并实际渲染 |
| PDF来源解析 | MinerU `parse_document`（需要PDF时的默认方法） | 无MinerU时明确告知后采用OCR/PDF解析，不凭空假定已安装 |
| 素材核对 | `view_image`；读取来源MD；文件哈希 | 同等图像查看与文件工具 |
| 逐页制作 | 主代理手工编写SVG；引用项目归档原图 | 可编辑页面描述 + 可验证原生PPTX后端 |
| 原图分图 | 原图不改动，SVG image + clipPath显示被选子图 | 无损提取；不能改变科研像素/色标或猜子图的方法名 |
| 状态和完整性 | PPT Master `page_workflow.py` 与原有检查器 | 本包独立 `workflow.py` + 后端实际QA |
| 预览 | `page_preview.py` 生成自包含HTML；Playwright调用无界面Edge截图 | 可靠浏览器、Office/LibreOffice渲染；记录实际源哈希 |
| 可视化审阅与回传 | 平台HTML组件/官方消息桥，按钮携带页ID、版本和哈希 | 原生组件回调、本地服务或平台表单；无回传能力则明示替代，不伪造批准 |
| 最终实页检查 | PowerPoint只读打开导出PPTX并逐页渲染；检查原生图片裁切和表格 | 实际Office/兼容渲染器及OOXML检查，说明所用程序，不混同源SVG预览 |
| 代码/技能检查 | Python、skill-creator `quick_validate.py` | 本模型平台的同等验证工具 |

本次曾遇到默认 Python 启动器不可用、浏览器控制工具失败。可迁移规则是“发现可用运行时并使用等价工具”，不是永久绑定某个私人安装路径或修改检查器绕过失败。完整性检查本身失败时应停止该后端。

可视化事件与自动衔接的具体约束见 [visual-review-protocol.md](visual-review-protocol.md)。按钮只负责传递用户意图，状态器成功记录后才显示已定稿；不要为复刻页面而引入另一套审批状态。

## PPT Master 适配器（安装该技能时才用）

定义 `PYTHON` 为实际可用解释器，`PM` 为平台提供的 ppt-master 绝对目录，`PROJECT` 为独立项目目录。以下是命令模板，不可照抄含占位符路径。Windows用PowerShell调用运算符 `&`，Unix使用相应shell。

```text
PYTHON PM/scripts/attribution_guard.py
# 先读取 PM/SKILL.md、routing.md、workflows/profiles/page-by-page.md。
# 根据当前页读 ppt-cover-page / ppt-toc-page / ppt-content-page 和必要构造分支。

PYTHON PM/scripts/page_workflow.py PROJECT init --name NAME --canvas 1280 720 --academic disabled
PYTHON PM/scripts/page_workflow.py PROJECT status
PYTHON PM/scripts/page_workflow.py PROJECT template --study STUDY_JSON --evidence ACTUAL_REPLY
PYTHON PM/scripts/page_workflow.py PROJECT asset --path FILE --kind original_image --label SOURCE_LABEL
PYTHON PM/scripts/page_workflow.py PROJECT add --kind content --brief BRIEF_JSON
PYTHON PM/scripts/page_workflow.py PROJECT confirm PAGE_ID --evidence ACTUAL_REPLY

# 主代理仅编写当前页SVG。原生表格/图表在SVG中同时写完整回退与JSON。
PYTHON PM/scripts/stamp_native_fallbacks.py PAGE_SVG --write
# 上一命令仅在页面使用SVG-first原生表格/图表标记时需要。
PYTHON PM/scripts/page_workflow.py PROJECT generated PAGE_ID
PYTHON PM/scripts/page_preview.py PROJECT PAGE_ID
# 渲染、检查、实际展示后才记录：
PYTHON PM/scripts/page_workflow.py PROJECT preview PAGE_ID --artifact HTML --shown-as SCREENSHOT
# 用户在预览之后明确定稿：
PYTHON PM/scripts/page_workflow.py PROJECT approve PAGE_ID --evidence ACTUAL_REPLY

# 修改：必须在覆盖被追踪源文件前执行：
PYTHON PM/scripts/page_workflow.py PROJECT reopen PAGE_ID --brief REVISED_BRIEF --evidence ACTUAL_REQUEST
# 然后重新confirm、制作、generated、预览、approve。

# 只有用户要求汇总且全部页定稿：
PYTHON PM/scripts/page_workflow.py PROJECT audit
PYTHON PM/scripts/page_workflow.py PROJECT export --evidence ACTUAL_EXPORT_REQUEST
```

原生表格/图表需要在后端支持的导出入口显式启用 `--native-charts-and-tables` 并检查真实PPTX结构。若逐页汇总入口不支持该参数，先查其正式文档和配置，不给CLI杜撰选项，也不将回退形状误称原生表格。

模板检查采用只读导入，**不是**把原PPTX母版静默嫁接到新稿：

```text
PYTHON PM/scripts/pptx_template_import.py TEMPLATE_PPTX -o INSPECTION_DIR --inheritance-mode both
```

SVG原则：`viewBox`决定画布；新页面平铺所有可见对象；有稳定组ID和模块边界；文字角色绑定确认的字体/pt字号/颜色；`baseline-shift="sub|super"`用于可编辑上下标。表格的全部行列、颜色、字重、对齐、精度、边框必须同时存在于可见回退和原生数据中。不要复制上游私有代码或省略其完整性门禁。

## 独立后端（没有PPT Master）

本包 `workflow.py` **只负责关卡和证据，不生成艺术稿、不编译PPTX、不自动批准**。完整CLI见 `state-and-schema.md`。`render_preview.mjs` 负责把已经完成的SVG嵌入本地HTML并用Playwright截图，要求预先安装可用的Node、Playwright和浏览器。

```text
node SKILL/scripts/render_preview.mjs --svg PAGE.svg --outdir PREVIEW_DIR --browser BROWSER_EXE
# 若Node无法发现Playwright，可补 --module-root NODE_MODULES_DIR。
```

不得未经允许运行 `npm install`、联网下载字体/浏览器或启动可见交互窗口。源SVG不允许脚本、事件处理器或外部网络资源；相对图片会嵌入预览，源文件不被改写。

中间文件使用宿主明确授权的项目或临时目录。最终源、状态、历史和预览属于项目产物，按项目目录保存。运行时位置与临时目录通过环境/参数指定，不写死到可移植核心。
