#!/usr/bin/env node
// Render completed local SVG artwork; never authors a slide or records approval.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const args = {};
for (let i = 2; i < process.argv.length; i += 2) {
  if (!process.argv[i]?.startsWith('--') || !process.argv[i + 1]) throw new Error('Use --svg FILE --outdir DIR [--browser EXE] [--module-root NODE_MODULES] [--resource-root DIR].');
  args[process.argv[i].slice(2)] = process.argv[i + 1];
}
if (!args.svg || !args.outdir) throw new Error('--svg and --outdir are required.');
const source = path.resolve(args.svg), out = path.resolve(args.outdir);
const resourceRoot = fs.realpathSync(path.resolve(args['resource-root'] || path.dirname(path.dirname(source))));
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const sourceBytes = fs.readFileSync(source);
const assets = {};
const mime = {'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.svg':'image/svg+xml'};
function embed(file, seen = new Set()) {
  const absolute = fs.realpathSync(path.resolve(file));
  if (seen.has(absolute) || seen.size > 10) throw new Error('Recursive SVG dependency.');
  const next = new Set(seen); next.add(absolute);
  let xml = fs.readFileSync(absolute, 'utf8');
  if (/<\s*(script|foreignObject)\b/i.test(xml) || /\bon[a-z]+\s*=/i.test(xml) || /url\(\s*['"]?https?:/i.test(xml)) throw new Error('Active or network SVG content is not supported.');
  xml = xml.replace(/<image\b[^>]*>/gi, tag => tag.replace(/((?:xlink:)?href)\s*=\s*(["'])(.*?)\2/gi, (_, key, quote, value) => {
    if (value.startsWith('data:image/')) return `${key}=${quote}${value}${quote}`;
    if (/^(?:[a-z]+:|\/\/)/i.test(value)) throw new Error('Use project-local images, not network/file URL image references.');
    const target = fs.realpathSync(path.resolve(path.dirname(absolute), value));
    const relative = path.relative(resourceRoot, target);
    if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('Image escapes --resource-root.');
    const extension = path.extname(target).toLowerCase();
    if (!mime[extension]) throw new Error(`Unsupported image type: ${extension}`);
    const raw = fs.readFileSync(target); assets[target] = hash(raw);
    const bytes = extension === '.svg' ? Buffer.from(embed(target, next)) : raw;
    return `${key}=${quote}data:${mime[extension]};base64,${bytes.toString('base64')}${quote}`;
  }));
  return xml;
}
const svg = embed(source).replace(/^\s*<\?xml[^>]*>\s*/i, '');
const viewBox = svg.match(/viewBox\s*=\s*["']0\s+0\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)["']/i);
if (!viewBox) throw new Error('Expected a positive 0 0 W H viewBox.');
const width = Number(viewBox[1]), height = Number(viewBox[2]);
if (!(width > 0 && height > 0)) throw new Error('Invalid canvas.');
fs.mkdirSync(out, {recursive:true});
const html = `<!doctype html><html><meta charset="utf-8"><meta name="source-sha256" content="${hash(sourceBytes)}"><style>body{margin:0;background:#eee}main{width:${width}px}main>svg{display:block;width:${width}px;height:${height}px;background:white}</style><main>${svg}</main></html>`;
const htmlPath = path.join(out, 'index.html'), pngPath = path.join(out, 'preview.png');
fs.writeFileSync(htmlPath, html);
const require = createRequire(import.meta.url);
const {chromium} = require(args['module-root'] ? path.join(path.resolve(args['module-root']), 'playwright') : 'playwright');
const browser = await chromium.launch({headless:true, ...(args.browser ? {executablePath:path.resolve(args.browser)} : {})});
let version;
try {
  version = browser.version();
  const page = await browser.newPage({viewport:{width:Math.ceil(width),height:Math.ceil(height)},deviceScaleFactor:1});
  await page.goto(pathToFileURL(htmlPath).href, {waitUntil:'load'});
  await page.evaluate(() => document.fonts.ready);
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  await page.locator('main > svg').screenshot({path:pngPath});
} finally { await browser.close(); }
const receipt = {source,source_sha256:hash(sourceBytes),assets,html:htmlPath,html_sha256:hash(fs.readFileSync(htmlPath)),screenshot:pngPath,screenshot_sha256:hash(fs.readFileSync(pngPath)),browser_version:version,device_scale_factor:1,canvas:[width,height]};
fs.writeFileSync(path.join(out, 'render-receipt.json'), JSON.stringify(receipt,null,2));
console.log(JSON.stringify(receipt,null,2));
