#!/usr/bin/env python3
"""Portable, single-writer page approval ledger. Not a slide generator or exporter."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import sys
from datetime import datetime, timezone


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".pending")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def evidence(value):
    require(bool(value and value.strip()), "Actual user evidence must not be blank.")
    return value.strip()


def existing(path):
    path = Path(path).expanduser().resolve()
    require(path.is_file(), f"Missing file: {path}")
    return path


def record(path):
    path = existing(path)
    return {"path": str(path), "sha256": digest(path)}


def verify(item):
    require(digest(existing(item["path"])) == item["sha256"], f"Stale file: {item['path']}")


def brief_check(b, assets):
    require(isinstance(b, dict), "Brief must be an object.")
    for field in ("title", "language", "layout", "alignment", "spacing", "template_application"):
        require(isinstance(b.get(field), str) and b[field].strip(), f"Missing brief field: {field}")
    require(b.get("kind") in {"cover", "toc", "content", "section", "ending"}, "Invalid page kind.")
    require(isinstance(b.get("content"), list) and bool(b["content"]), "Content must be a nonempty list.")
    require(isinstance(b.get("materials"), list), "materials must contain registered asset IDs.")
    for key in b["materials"]:
        require(isinstance(key, str) and key in assets, f"Unregistered asset: {key}")
    require(isinstance(b.get("text_roles"), dict) and bool(b["text_roles"]), "Missing text_roles.")
    for key, role in b["text_roles"].items():
        require(isinstance(role, dict), f"Invalid text role: {key}")
        require(isinstance(role.get("font"), str) and role["font"].strip(), f"Missing font: {key}")
        size = role.get("size_pt")
        require(isinstance(size, (int, float)) and not isinstance(size, bool) and math.isfinite(size) and size > 0,
                f"Positive finite pt size required: {key}")
        require(isinstance(role.get("color"), str) and bool(re.fullmatch(r"#[0-9A-Fa-f]{6}", role["color"])),
                f"Explicit #RRGGBB color required: {key}")


def get_page(state, page_id):
    for page in state["pages"]:
        if page["id"] == page_id:
            return page
    raise ValueError(f"Unknown page: {page_id}")


def inputs(state, page):
    verify(page["brief_file"])
    b = load(page["brief_file"]["path"])
    brief_check(b, state["assets"])
    template = state["template"]
    require(template is not None, "Template decision not confirmed.")
    if not template.get("skip"):
        verify(template["source"])
        verify(template["study"])
    materials = {}
    for key in b["materials"]:
        verify(state["assets"][key])
        materials[key] = state["assets"][key]["sha256"]
    return hashlib.sha256(canonical({"brief": page["brief_file"]["sha256"], "template": template,
                                     "materials": materials, "canvas": state["canvas"]}).encode()).hexdigest()


def generated_check(state, page):
    item = page.get("generated")
    require(item is not None, "No validated generated artifact.")
    require(inputs(state, page) == item["inputs_sha256"], "Inputs changed; reopen and revalidate this page.")
    verify(item["artifact"])
    verify(item["qa"])


def approved_check(state, page):
    require(page["status"] == "approved", f"Not approved: {page['id']}")
    generated_check(state, page)
    verify(page["preview"]["artifact"])
    require(page["approval"]["preview_sha256"] == page["preview"]["artifact"]["sha256"], "Preview changed.")


def audit(state):
    require(bool(state["pages"]), "No pages to export.")
    for page in state["pages"]:
        approved_check(state, page)
    return {"passed": True, "approved_order": [p["id"] for p in state["pages"]],
            "source_sha256": {p["id"]: p["generated"]["artifact"]["sha256"] for p in state["pages"]}}


def project_file(path, project):
    path = existing(path)
    require(path.is_relative_to(project / "product"), "Page/preview artifacts must be inside project/product.")
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project")
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--main", required=True)
    init.add_argument("--name", required=True)
    init.add_argument("--canvas", nargs=2, type=int, default=[1280, 720])
    init.add_argument("--academic", choices=["enabled", "disabled", "undecided"], default="undecided")
    for name in ("status", "audit"):
        sub.add_parser(name)
    settings = sub.add_parser("settings")
    settings.add_argument("--academic", choices=["enabled", "disabled"], required=True)
    template = sub.add_parser("template")
    choice = template.add_mutually_exclusive_group(required=True)
    choice.add_argument("--path")
    choice.add_argument("--skip", action="store_true")
    template.add_argument("--study")
    asset = sub.add_parser("asset")
    asset.add_argument("--path", required=True)
    asset.add_argument("--kind", required=True, choices=["text", "original_image", "generated_diagram", "slide_draft", "reference_template"])
    asset.add_argument("--label", required=True)
    add = sub.add_parser("add")
    add.add_argument("--brief", required=True)
    for name in ("confirm", "generated", "preview", "approve", "reopen"):
        item = sub.add_parser(name)
        item.add_argument("--page", required=True)
        if name == "generated":
            item.add_argument("--artifact", required=True)
            item.add_argument("--qa", required=True)
        elif name == "preview":
            item.add_argument("--artifact", required=True)
            item.add_argument("--shown-as", required=True)
        elif name == "reopen":
            item.add_argument("--brief", required=True)
    sub.add_parser("export-ready")
    for name in ("settings", "template", "confirm", "approve", "reopen", "export-ready"):
        sub.choices[name].add_argument("--evidence", required=True)
    args = parser.parse_args()

    if args.command == "init":
        require(bool(args.name.strip()) and args.name not in {".", ".."} and
                not re.search(r'[\\/:*?"<>|]', args.name) and args.name == args.name.rstrip(" ."), "Unsafe project name.")
        require(not re.fullmatch(r"(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", args.name), "Reserved project name.")
        require(all(v > 0 for v in args.canvas), "Canvas dimensions must be positive.")
        root = Path(args.main).expanduser().resolve()
        project = (root / args.name).resolve()
        require(project.parent == root, "Project must be a direct child of main folder.")
    else:
        require(args.project, "--project is required for this command.")
        project = Path(args.project).expanduser().resolve()
    work = project / "product" / "page-by-page"
    state_path = work / "portable_workflow.json"
    require(not (work / "page_workflow.json").exists(), "PPT Master state exists; use its backend, do not migrate silently.")
    if args.command == "init":
        require(not state_path.exists(), "Project already initialized; use status.")
        for folder in (root / "sources", project / "output", work / "briefs", work / "materials", work / "svg_output", work / "previews"):
            folder.mkdir(parents=True, exist_ok=True)
        state = {"schema_version": 1, "backend": "portable", "project_name": args.name,
                 "canvas": args.canvas, "academic": args.academic, "template": None, "assets": {}, "pages": [], "export_requests": []}
        write(state_path, state)
        print(project)
        return

    state = load(state_path)
    command = args.command
    if command == "status":
        print(json.dumps({"project": str(project), "academic": state["academic"],
                          "pages": [{k: p[k] for k in ("id", "revision", "status")} for p in state["pages"]]}, ensure_ascii=False))
        return
    if command == "audit":
        print(json.dumps(audit(state), ensure_ascii=False))
        return
    result = None
    if command == "settings":
        require(not state["pages"], "Preset changes on an existing deck require explicit affected-page revision.")
        state["academic"] = args.academic
        state["academic_evidence"] = evidence(args.evidence)
    elif command == "template":
        require(not state["pages"], "Cannot replace a deck's template after authoring without a revision plan.")
        item = {"skip": bool(args.skip), "evidence": evidence(args.evidence)}
        if not args.skip:
            require(args.study, "Template observations JSON is required.")
            require(isinstance(load(existing(args.study)), dict), "Study must be a JSON object.")
            item.update(source=record(args.path), study=record(args.study))
        state["template"] = item
    elif command == "asset":
        source = existing(args.path)
        key = f"a{len(state['assets']) + 1:04}"
        target = work / "materials" / (key + source.suffix.lower())
        shutil.copy2(source, target)
        state["assets"][key] = dict(record(target), source=str(source), kind=args.kind, label=args.label)
        result = key
    elif command == "add":
        require(state["academic"] != "undecided", "Resolve optional preset before page authoring.")
        require(state["template"] is not None, "Confirm template observations or explicit no-template exception.")
        for old in state["pages"]:
            approved_check(state, old)
        b = load(existing(args.brief))
        brief_check(b, state["assets"])
        key = f"p{len(state['pages']) + 1:04}"
        path = work / "briefs" / f"{key}_r001.json"
        write(path, b)
        page = {"id": key, "revision": 1, "status": "brief_draft", "brief_file": record(path), "history": []}
        inputs(state, page)
        state["pages"].append(page)
        result = key
    elif command == "export-ready":
        receipt = dict(audit(state), evidence=evidence(args.evidence),
                       requested_at=datetime.now(timezone.utc).isoformat(), kind="export-readiness-only")
        state["export_requests"].append(receipt)
        result = receipt
    else:
        page = get_page(state, args.page)
        if command == "confirm":
            require(page["status"] == "brief_draft", "Only a draft can receive parameter confirmation.")
            page["confirmed_inputs"] = inputs(state, page)
            page["brief_evidence"] = evidence(args.evidence)
            page["status"] = "brief_confirmed"
        elif command == "generated":
            require(page["status"] == "brief_confirmed", "Confirm current parameters before generation; reopen tracked versions before edits.")
            require(inputs(state, page) == page["confirmed_inputs"], "Confirmed inputs changed.")
            artifact = project_file(args.artifact, project)
            report = load(existing(args.qa))
            require(report.get("passed") is True and report.get("artifact_sha256") == digest(artifact), "QA must pass for this exact artifact hash.")
            require(isinstance(report.get("checks"), list) and bool(report["checks"]) and all(isinstance(x, str) and x.strip() for x in report["checks"]), "QA checks must be documented.")
            qa_path = work / "validation" / f"{page['id']}_r{page['revision']:03}_qa.json"
            write(qa_path, report)
            page["generated"] = {"artifact": record(artifact), "qa": record(qa_path), "inputs_sha256": inputs(state, page)}
            page["status"] = "generated"
        elif command == "preview":
            require(page["status"] == "generated", "Preview must follow validation of this revision.")
            generated_check(state, page)
            require(bool(args.shown_as.strip()), "Record the actual displayed image/URL.")
            page["preview"] = {"artifact": record(project_file(args.artifact, project)), "shown_as": args.shown_as}
            page["status"] = "previewed"
        elif command == "approve":
            require(page["status"] == "previewed", "Approval is only allowed after showing this revision's preview.")
            generated_check(state, page)
            verify(page["preview"]["artifact"])
            page["approval"] = {"evidence": evidence(args.evidence), "preview_sha256": page["preview"]["artifact"]["sha256"]}
            page["status"] = "approved"
        elif command == "reopen":
            b = load(existing(args.brief))
            brief_check(b, state["assets"])
            ev = evidence(args.evidence)
            archive = work / "history" / page["id"] / f"r{page['revision']:03}"
            archive.mkdir(parents=True, exist_ok=False)
            snapshot = copy.deepcopy(page)
            write(archive / "page_record.json", snapshot)
            files = {"brief.json": page["brief_file"]}
            if page.get("generated"):
                files.update({"source" + Path(page["generated"]["artifact"]["path"]).suffix: page["generated"]["artifact"], "qa.json": page["generated"]["qa"]})
            if page.get("preview"):
                files["preview" + Path(page["preview"]["artifact"]["path"]).suffix] = page["preview"]["artifact"]
            copied = {}
            for name, item in files.items():
                if Path(item["path"]).is_file():
                    shutil.copy2(item["path"], archive / name)
                    copied[name] = record(archive / name)
            write(archive / "archived_files.json", copied)
            revision = page["revision"] + 1
            path = work / "briefs" / f"{page['id']}_r{revision:03}.json"
            write(path, b)
            updated = {"id": page["id"], "revision": revision, "status": "brief_draft", "brief_file": record(path),
                       "history": page["history"] + [{"directory": str(archive), "evidence": ev}]}
            page.clear()
            page.update(updated)
            inputs(state, page)
    write(state_path, state)
    if result is not None:
        print(result if isinstance(result, str) else json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(f"[BLOCKED] {error}", file=sys.stderr)
        sys.exit(2)
