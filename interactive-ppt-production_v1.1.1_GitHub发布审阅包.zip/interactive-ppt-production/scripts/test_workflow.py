#!/usr/bin/env python3
"""Integration tests using simulated QA/image fixtures, not production slide QA."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tmp-root', required=True, help='Explicit approved temporary parent directory')
    args = parser.parse_args()
    root = Path(args.tmp_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ppt-skill-test-', dir=root) as name:
        test = Path(name).resolve()
        assert test.is_relative_to(root) and test != root  # verify cleanup target is bounded
        project = test / 'main' / 'Demo'
        tool = Path(__file__).with_name('workflow.py')

        def run(*values, ok=True, initial=False):
            prefix = [] if initial else ['--project', str(project)]
            result = subprocess.run([sys.executable, str(tool), *prefix, *map(str, values)], capture_output=True, text=True, encoding='utf-8')
            assert (result.returncode == 0) == ok, (values, result.stdout, result.stderr)
            return result.stdout.strip()

        run('init','--main',test/'main','--name','Demo',initial=True)
        template = test/'template.pptx'; template.write_bytes(b'template-hash-fixture')
        study = test/'study.json'; study.write_text('{}',encoding='utf-8')
        run('template','--path',template,'--study',study,'--evidence','Test user confirms observed template')
        image = test/'figure.png'; image.write_bytes(b'image-hash-fixture')
        asset = run('asset','--path',image,'--kind','original_image','--label','test fixture, not scientific evidence')
        brief = {'kind':'content','title':'Fixture','content':['Test only'],'language':'en-US','layout':'single column','alignment':'left','spacing':'1.4','template_application':'explicit test fixture','materials':[asset],'text_roles':{'body':{'font':'Arial','size_pt':18,'color':'#000000'}}}
        brief_file = test/'brief.json'; brief_file.write_text(json.dumps(brief),encoding='utf-8')
        run('add','--brief',brief_file,ok=False)  # academic choice unresolved
        run('settings','--academic','disabled','--evidence','Test user explicitly disables preset')
        page = run('add','--brief',brief_file)
        run('approve','--page',page,'--evidence','yes',ok=False)
        run('add','--brief',brief_file,ok=False)
        run('confirm','--page',page,'--evidence','yes, create current preview')
        work = project/'product'/'page-by-page'
        source = work/'svg_output'/'fixture.svg'
        source.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720"/>',encoding='utf-8')
        qa = test/'qa.json'
        qa.write_text(json.dumps({'passed':True,'artifact_sha256':'wrong','checks':['simulated test check']}),encoding='utf-8')
        run('generated','--page',page,'--artifact',source,'--qa',qa,ok=False)
        qa.write_text(json.dumps({'passed':True,'artifact_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'checks':['simulated test check; not production QA']}),encoding='utf-8')

        def finish():
            run('generated','--page',page,'--artifact',source,'--qa',qa)
            run('approve','--page',page,'--evidence','yes',ok=False)
            preview = work/'previews'/'fixture.png'; preview.write_bytes(b'preview-hash-fixture')
            run('preview','--page',page,'--artifact',preview,'--shown-as','simulated test display')
            run('approve','--page',page,'--evidence','yes, current page final')
            run('audit')

        finish()
        good = source.read_bytes(); source.write_bytes(good+b'changed')
        run('audit',ok=False); source.write_bytes(good)
        state_path = work/'portable_workflow.json'
        state = json.loads(state_path.read_text(encoding='utf-8'))
        archived_asset = Path(state['assets'][asset]['path'])
        good_asset = archived_asset.read_bytes(); archived_asset.write_bytes(b'changed')
        run('audit',ok=False); archived_asset.write_bytes(good_asset)
        stored_brief = Path(state['pages'][0]['brief_file']['path'])
        good_brief = stored_brief.read_bytes(); stored_brief.write_bytes(good_brief+b' ')
        run('audit',ok=False); stored_brief.write_bytes(good_brief)
        brief['text_roles']['body']['size_pt'] = 16
        brief_file.write_text(json.dumps(brief),encoding='utf-8')
        run('reopen','--page',page,'--brief',brief_file,'--evidence','test user requests 16 pt')
        assert (work/'history'/page/'r001'/'source.svg').read_bytes() == good
        run('audit',ok=False)
        run('confirm','--page',page,'--evidence','yes, 16 pt')
        finish()
        receipt = json.loads(run('export-ready','--evidence','test user explicitly asks to export'))
        assert receipt['kind'] == 'export-readiness-only'
        legacy = test/'main'/'Legacy'/'product'/'page-by-page'
        legacy.mkdir(parents=True); (legacy/'page_workflow.json').write_text('{}',encoding='utf-8')
        run('init','--main',test/'main','--name','Legacy',initial=True,ok=False)
        print('PASS: preset, parameter, preview and approval gates; single pending page; stale input detection; revision archive; export readiness; no silent backend migration.')


if __name__ == '__main__':
    main()
